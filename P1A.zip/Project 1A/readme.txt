Simple calculator using regex and eval
